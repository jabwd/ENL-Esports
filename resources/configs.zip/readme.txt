Global ET Config

version 1 August 2011

Upload all the files in the same array of folders to your ETPro server.

Files in etpro:

configs/global1.config
configs/global3.config
configs/global5.config
configs/global6.config
globalmapscripts/adlernest.script
globalmapscripts/braundorf_b4.script
globalmapscripts/bremen_b2.script
globalmapscripts/bremen_b3.scripts
globalmapscripts/caen.script
globalmapscripts/et_beach.script
globalmapscripts/et_ice.script
globalmapscripts/et_ufo_final.script
globalmapscripts/frostbite.script
globalmapscripts/karsiah_te2.script
globalmapscripts/mp_sub_rc1.script
globalmapscripts/radar.script
globalmapscripts/supply.script
globalmapscripts/sw_goldrush_te.script
globalmapscripts/sw_oasis_b3.script
globalmapscripts/tc_base.script
globalmapscripts/te_escape2.script
combinedglobalf.lua
combinedglobalr.lua

Do not change anything or the config won't be certified anymore, thank you for understanding.

Thanks for all the people who helped me out (burneddi and h3ll, lots of thanks)

Contact:
pds @ #exitium.et (QuakeNet)

20:53 24-8-2011