-- global 5on5 lua fixes
-- version: 1
-- changelog: 
-- cleaned up code
-- based on globalwinter2010cfgs/mapscripts
-- first release
-- all original work copyright -> reyalp@gmail.com
-- contact pds
-- #exitium.et

function et_ClientCommand(cno,cmd)
	cmd = string.lower(cmd)
	if cmd == "forcetapout" then
		if et.gentity_get(cno, "r.contents") == 0 then
			return 1
   		end
	end
	if cmd == "class" then
		if et.trap_Argv(1) == "c" then
			if et.trap_Argv(2) == "3" then
				for j = 0, (maxclients - 1) do
				if getTeam(j) == 2 and getWeapon(j) == 41 then
					sniperallies = sniperallies +1
				end
			end
			if getWeapon(cno) == 41 then
				sniperallies = sniperallies -1
			end
			if sniperallies > 0 then
				sniperallies = 0
				setPlayerWeapon(cno , 10)
				return 1
			end
			for j = 0, (maxclients - 1) do
			if getTeam(j) == 1 and getWeapon(j) == 32 then
				sniperaxis = sniperaxis +1
			end
		end
		if getWeapon(cno) == 32 then
			sniperaxis = sniperaxis -1
		end
		if sniperaxis > 0 then
			sniperaxis = 0
			setPlayerWeapon(cno , 10)
			return 1
		end
			end
		end
	end

	if cmd == "team" then
		if et.trap_Argv(1) == "b" then
			if et.trap_Argv(2) == "4" then
	  			if et.trap_Argv(3) == "25" then
	   				for j = 0, (maxclients - 1) do
					if getTeam(j) == 2 and getWeapon(j) == 25 then
						sniperallies = sniperallies +1
					end
				end
			if getWeapon(cno) == 25 then
				sniperallies = sniperallies -1
			end
			if sniperallies > 0 then
				sniperallies = 0
				setPlayerWeapon(cno , 10) 
				return 1
		 	end
				end
			end
		end
	end
	if cmd == "team" then
		if et.trap_Argv(1) == "r" then
			if et.trap_Argv(2) == "4" then
				if et.trap_Argv(3) == "32" then
					for j = 0, (maxclients - 1) do
					if getTeam(j) == 1 and getWeapon(j) == 32 then
						sniperaxis = sniperaxis +1
					end
				end
				if getWeapon(cno) == 32 then
					sniperaxis = sniperaxis -1
				end
				if sniperaxis > 0 then
					sniperaxis = 0
					setPlayerWeapon(cno , 10)
					return 1
		 		end
			end
			end
		end
	end
	if cmd == "ws" then
		local n = tonumber(et.trap_Argv(1))
		if not n then
			et.G_LogPrint(string.format("wsfix: client %d bad ws not a number [%s]\n",cno,tostring(et.trap_Argv(1))))
			return 1
		end
		if n < 0 or n > 21 then
			et.G_LogPrint(string.format("wsfix: client %d bad ws %d\n",cno,n))
			return 1
		end
		return 0
	end
	if cmd == "callvote" or cmd == "ref" or cmd == "sa" or cmd == "semiadmin" then
		local args=et.ConcatArgs(1) 
		if string.find(args,"[\r\n]") then
			et.G_LogPrint(string.format("combinedfixes: client %d bad %s [%s]\n",cno,cmd,args))
			return 1;
		end
		return 0
	end
	return 0
end


badnames = {
--	'^ShutdownGame',
--	'^ClientBegin',
--	'^ClientDisconnect',
--	'^ExitLevel',
--	'^Timelimit',
--	'^EndRound',
	'^etpro IAC',
--	'^etpro privmsg',
-- "say" is relatively likely to have false positives
-- but can potentially be used to exploit things that use etadmin_mod style !commands
--	'^say',
--	'^Callvote',
--	'^broadcast'
}

function check_userinfo( cno )
	local userinfo = et.trap_GetUserinfo(cno)
	if string.len(userinfo) > 980 then
		return "oversized"
	end
	if string.find(userinfo,"\n") then
		return "new line"
	end
	if (string.sub(userinfo,1,1) ~= "\\" ) then
		return "missing leading slash"
	end
	if (string.sub(userinfo,-1,1) == "\\" ) then
		return "trailing slash"
	end
	local n = 0
	for _ in string.gfind(userinfo,"\\") do
		n = n + 1
	end
	if math.mod(n,2) == 1 then
		return "unbalanced"
	end

	local m
	local t = {}

	for m in string.gfind(userinfo,"\\([^\\]*)\\") do
		if string.len(m) == 0 then
			return "empty key"
		end
		m = string.lower(m)
		if t[m] then
			return "duplicate key"
		end
		t[m] = true 
	end
	local ip = et.Info_ValueForKey( userinfo, "ip" )
	if ip == "" then
		return "missing ip"
	end
	if string.find(ip,"^%d+%.%d+%.%d+%.%d+:%d+$") == nil then
		return "malformed ip"
	end
	local name = et.Info_ValueForKey( userinfo, "name" )
	if name == "" then
		return "missing name"
	end
	for _, badnamepat in ipairs(badnames) do
		local mstart,mend,cno = string.find(name,badnamepat)
		if mstart then
			return "name abuse"
		end
	end
end

infocheck_lasttime=0
infocheck_client=0
infocheck_freq=5000

function et_RunFrame( leveltime )
	if ( infocheck_lasttime + infocheck_freq > leveltime ) then
		return
	end
	infocheck_lasttime = leveltime
	if ( et.gentity_get( infocheck_client, "inuse" ) ) then
		local reason = check_userinfo( infocheck_client )
		if ( reason ) then
			et.G_LogPrint(string.format("userinfocheck frame: client %d bad userinfo %s\n",infocheck_client,reason))
			et.trap_SetUserinfo( infocheck_client, "name\\badinfo" )
			et.trap_DropClient( infocheck_client, "bad userinfo", 0 )
		end
	end

	infocheck_client = infocheck_client + 1
	if ( infocheck_client >= tonumber(et.trap_Cvar_Get("sv_maxclients")) ) then
		infocheck_client = 0
	end
end

function et_ClientUserinfoChanged( cno )
	local reason = check_userinfo( cno )
	if ( reason ) then
		et.G_LogPrint(string.format("userinfocheck infochanged: client %d bad userinfo %s\n",cno,reason))
		et.trap_SetUserinfo( cno, "name\\badinfo" )
		et.trap_DropClient( cno, "bad userinfo", 0 )
	end
end

DEF_GUIDCHECK_BANTIME = 0

function bad_guid(cno,reason)
	local bantime = tonumber(et.trap_Cvar_Get( "guidcheck_bantime" ))
	if not bantime or bantime < 0 then
		bantime = DEF_GUIDCHECK_BANTIME
	end

	et.G_LogPrint(string.format("guidcheck: client %d bad GUID %s\n",cno,reason))
	et.trap_DropClient(cno,"You are banned from this server",bantime)
end

function check_guid_line(text)
	local guid,netname
	local mstart,mend,cno = string.find(text,"^etpro IAC: (%d+) GUID %[")
	if not mstart then
		return
	end
	text=string.sub(text,mend+1)
	mstart,mend,guid = string.find(text,"^([^%]]*)%] %[")
	if not mstart then
		bad_guid(cno,"couldn't parse guid")
		return
	end
	text=string.sub(text,mend+1)
	netname = et.gentity_get(cno,"pers.netname")
	mstart,mend = string.find(text,netname,1,true)
	if not mstart or mstart ~= 1 then
		bad_guid(cno,"couldn't parse name")
		return
	end
	text=string.sub(text,mend+1)
	if text ~= "]\n" then
		bad_guid(cno,"trailing garbage")
		return
	end
	mstart,mend = string.find(guid,"^%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x$")
	if not mstart then
		bad_guid(cno,"malformed")
		return
	end
end

function et_Print(text)
	check_guid_line(text)
end

DEF_IP_MAX_CLIENTS = 3
et.G_Printf = function(...)
		et.G_Print(string.format(unpack(arg)))
end

function IPForClient(cno)
	local userinfo = et.trap_GetUserinfo( cno ) 
	if userinfo == "" then
		return ""
	end
	local ip = et.Info_ValueForKey( userinfo, "ip" )
	local ipstart, ipend, ipmatch = string.find(ip,"(%d+%.%d+%.%d+%.%d+)")
	if not ipstart then
		return ""
	end
	return ipmatch
end

function et_ClientConnect( cno, firstTime, isBot )
	local reason = check_userinfo( cno )
	if ( reason ) then
		et.G_LogPrint(string.format("userinfocheck connect: client %d bad userinfo %s\n",cno,reason))
		return "bad userinfo"
	end
	local ip = IPForClient( cno )
	local count = 1
	local max = tonumber(et.trap_Cvar_Get( "ip_max_clients" ))
	if not max or max <= 0 then
		max = DEF_IP_MAX_CLIENTS
	end
	local userinfo = et.trap_GetUserinfo( cno )
	if et.Info_ValueForKey( userinfo, "rate" ) == "" then 
		et.G_Printf("fakeplimit.lua: invalid userinfo from %s\n",ip)
		return "invalid connection"
	end
	for i = 0, et.trap_Cvar_Get("sv_maxclients") - 1 do
		if i ~= cno and et.gentity_get(i,"pers.connected") > 0 and ip == IPForClient(i) then
			count = count + 1
			if count > max then
				et.G_Printf("fakeplimit.lua: too many connections from %s\n",ip)
				return string.format("only %d connections per IP are allowed on this server",max)
			end
		end
	end
end

function et_InitGame(levelTime,randomSeed,restart)
	maxclients = tonumber( et.trap_Cvar_Get( "sv_maxClients" ) )	
	sniperaxis = 0
	sniperallies = 0
end

function getWeapon(playerID)
    return et.gentity_get(playerID, "sess.playerWeapon")
end 

function getTeam(playerID)
    return et.gentity_get(playerID, "sess.sessionTeam")
end 

function setPlayerWeapon(playerID , weapon)
    et.gentity_set(playerID, "sess.latchPlayerWeapon", weapon)
end 

function et_ClientSpawn(cno,revived)
	if revived == 0 and et.gentity_get(cno, "sess.playerType") == 2 then
		et.gentity_set(cno,"ps.ammo",39,3)
		et.gentity_set(cno,"ps.ammo",40,3)
	end
end

